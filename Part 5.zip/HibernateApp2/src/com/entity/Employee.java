package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Emp_InfoTest")
public class Employee {
	@Id
	@Column(name="Emp_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	int eid;
	@Column(name="Emp_NAME",length=20,nullable=false)
	String name;
	@Column(name="Mobile_No",unique=true)
	String mobno;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	
	
	

}
