package com.web.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.spring.model.Book;
@Controller
public class SpringController {
@RequestMapping("/bookapp")
public ModelAndView hello()
{
return new ModelAndView("hello","msg","Welcome Spring MVC");
}
@RequestMapping(value="/book",method=RequestMethod.GET)
public ModelAndView book()
{
	return new ModelAndView("input","command",new Book());
}
@RequestMapping(value="/addbook",method=RequestMethod.POST)
public ModelAndView addBook(Book b)
{
	ModelAndView model=new ModelAndView("bookinfo");
	model.addObject("name",b.getName());
	model.addObject("author",b.getAuthor());
	model.addObject("price",b.getPrice());
	return model;
}

}
