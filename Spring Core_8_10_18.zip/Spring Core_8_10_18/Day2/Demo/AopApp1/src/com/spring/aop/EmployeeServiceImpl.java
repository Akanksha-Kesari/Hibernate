package com.spring.aop;
public class EmployeeServiceImpl implements EmployeeService {
	@Override
	public void getEmployeebyName(int id, String name) {
		System.out.println("Eid "+id+" name "+name);
		
	}

	@Override
	public void addEmployee() {
		System.out.println("Core Method Employee Created..");		
	}

}
