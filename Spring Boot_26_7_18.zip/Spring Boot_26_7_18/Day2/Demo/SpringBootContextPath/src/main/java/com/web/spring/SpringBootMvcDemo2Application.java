package com.web.spring;
import java.util.HashMap;
import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringBootMvcDemo2Application {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcDemo2Application.class, args);
	}
}
