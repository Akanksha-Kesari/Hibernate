package com.web.spring.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.web.spring.bean.Project;

public class ProjectRowMapper implements RowMapper<Project> {
public Project mapRow(ResultSet rs,int rownum)throws SQLException
{
	Project p=new Project();
	p.setId(rs.getInt(1));
	p.setName(rs.getString(2));
	p.setDuration((rs.getInt(3)));
	
	return p;
}
	
	

}
