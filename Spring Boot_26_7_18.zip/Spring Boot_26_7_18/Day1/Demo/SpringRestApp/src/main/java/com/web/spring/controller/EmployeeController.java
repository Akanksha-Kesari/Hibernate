package com.web.spring.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.web.spring.model.Employee;
import com.web.spring.service.EmployeeInterface;
@RestController
@RequestMapping("/service")
public class EmployeeController {
	@Autowired
	private EmployeeInterface empserv;
	
	@RequestMapping(value="greet" ,method=RequestMethod.GET,
			produces="text/plain")
	public String greet()
	{
		return "Employee Management App";
	}
	
@RequestMapping(value="getemp" ,method=RequestMethod.GET,
		produces={"application/json" ,"application/xml"})
	public List<Employee>getEmpployee()
	{
		return empserv.getEmp();
	}
	
@RequestMapping(value="addemp" ,method=RequestMethod.POST,
consumes="application/json",produces="application/json")
	public String addEmpployee(@RequestBody Employee e)
	{
		empserv.addEmployee(e);
		return "Resource Created";
	}
	
}
