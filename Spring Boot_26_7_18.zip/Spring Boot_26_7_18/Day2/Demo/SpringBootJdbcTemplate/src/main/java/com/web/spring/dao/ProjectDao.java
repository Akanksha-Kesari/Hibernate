package com.web.spring.dao;
import java.util.List;
import com.web.spring.bean.Project;
public interface ProjectDao {
	List<Project> getAllProjects()throws Exception;
	void addProject(Project proj)throws Exception;
	}
