package com.spring.aop.around;
public class EmployeeServiceImpl implements EmployeeService{
	@Override
	public void getEmployeebyName(String name)throws NullPointerException {
		System.out.println("Get Emp byName is Called....");
	
		if (name==null)
		{
			throw new NullPointerException();
		}
		
		System.out.println("Emp name is "+name);
	}

	
	}


