package com.spring.config;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import com.spring.model.Employee;
import com.spring.model.Employee1;
import com.spring.model.HelloWrold;
public class MainApp {
public static void main(String[] args) {
//HelloWrold h=new HelloWrold();
//Resource res=new ClassPathResource("spring.xml");
//BeanFactory context= new XmlBeanFactory(res);
	ApplicationContext context= 
	new AnnotationConfigApplicationContext(AppConfig.class);

//ApplicationContext context= 
//new ClassPathXmlApplicationContext("spring.xml");
HelloWrold h=(HelloWrold)context.getBean("helloBean");
Employee emp=(Employee)context.getBean("empBean");
Employee1 emp1=(Employee1)context.getBean("empBean1");
h.sayHello("Ravic");
System.out.println("Id "+emp.getId()+" Name"+emp.getName()+" Salary"+emp.getSal());
System.out.println(emp1);
	}
}
