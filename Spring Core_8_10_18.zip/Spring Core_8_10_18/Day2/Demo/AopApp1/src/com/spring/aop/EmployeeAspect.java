package com.spring.aop;

import java.util.Arrays;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
@Aspect
public class EmployeeAspect {
@Before("execution(* com.spring.aop.EmployeeService.getEmployeebyName(..))")
public void myBeforeAdvice(JoinPoint jp)// Adice Method
	{
	System.out.println("Before the execution Join Point");
	
	System.out.println("Entriing isndige getEmployeebyname"+
	jp.getSignature().getName());
	System.out.println("Arguments getEmployeebyname"
	+Arrays.toString(jp.getArgs()));
	System.out.println("Target clas"+jp.getTarget().getClass().getName());
	}
	
@After("execution(* com.spring.aop.EmployeeService.addEmployee(..))")
public void myAfterAdvice()// Adice Method
	{
	System.out.println("Employee Created...");
	}

}
