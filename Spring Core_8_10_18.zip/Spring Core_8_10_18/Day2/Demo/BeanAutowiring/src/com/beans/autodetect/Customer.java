package com.beans.autodetect;

import org.springframework.beans.factory.annotation.Autowired;
public class Customer {
	@Autowired(required=true)
	private Person p;
	private int type;
	private String action;

	public Person getP() {
		return p;
	}
	public void setP(Person p) {
		this.p = p;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	@Override
	public String toString() {
		return "Customer [p=" + p + ", type=" + type + ", action=" + action + "]";
	}
		
	}
