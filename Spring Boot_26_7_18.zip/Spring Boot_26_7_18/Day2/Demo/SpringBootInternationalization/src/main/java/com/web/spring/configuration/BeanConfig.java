package com.web.spring.configuration;
import java.util.Locale;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
@Configuration
public class BeanConfig extends WebMvcConfigurerAdapter{
  
	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor()
	{
	LocaleChangeInterceptor lci=new LocaleChangeInterceptor();
	lci.setParamName("lang");
	return lci;
		
	}
	
	@Bean
	public LocaleResolver localeResolver ()
	{
		CookieLocaleResolver clr=new CookieLocaleResolver();
		clr.setDefaultLocale(Locale.US);
		return clr;
	}
  
	@Bean
	public ReloadableResourceBundleMessageSource messageSource()
	{
		ReloadableResourceBundleMessageSource msg=new ReloadableResourceBundleMessageSource();
		msg.setBasename("classpath:messages");
		return msg;
	}
	@Override
	public void addInterceptors(InterceptorRegistry reg)
	{
		
		reg.addInterceptor(localeChangeInterceptor());
	}
	
	@Bean
	public InternalResourceViewResolver myresolver()
	{
		
		InternalResourceViewResolver res=new InternalResourceViewResolver();
		res.setPrefix("/WEB-INF/jsp/");
		res.setSuffix(".jsp");
		return res;
	}
	
	
  }