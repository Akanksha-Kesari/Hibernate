package com.beans.byname;
public class EmployeeBean {
	private String fullName;
	private DepartmentBean deptBean;
	public String getFullName() {
		return fullName;
	}
		public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public DepartmentBean getDeptBean() {
		return deptBean;
	}
	public void setDeptBean(DepartmentBean deptBean) {
		this.deptBean = deptBean;
	}
	}
