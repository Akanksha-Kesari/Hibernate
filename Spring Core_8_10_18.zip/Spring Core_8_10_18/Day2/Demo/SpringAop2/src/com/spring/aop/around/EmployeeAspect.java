package com.spring.aop.around;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
@Aspect
public class EmployeeAspect {
		//For all
		@Pointcut ("execution(* *.*(..))")
		public void allMethod(){}
		
		//call1 for all method
		@Around("allMethod()")
		public void logAround(ProceedingJoinPoint jpoint)throws Throwable
		{
			System.out.println("Before method execution");
		//  jpoint.proceed();
		  System.out.println("After method  execution");
		}
		@AfterThrowing("execution(* com.spring.aop.around.EmployeeService.getEmployeebyName(..))")
		public void afterThrowingAdvice()
		{
			System.out.println("Your can't pass null for employee name");
		}	
	}
