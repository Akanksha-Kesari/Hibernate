package com.spring.model;
public class HelloWrold {
	public void sayHello(String name)
	{
		System.out.println("Hello "+name);
	}

}
