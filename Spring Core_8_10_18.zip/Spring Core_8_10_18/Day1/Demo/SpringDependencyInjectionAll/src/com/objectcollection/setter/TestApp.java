package com.objectcollection.setter;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class TestApp {
	public static void main(String[] args) {
		Resource r=new ClassPathResource("com/objectcollection/setter/spring.xml");
		BeanFactory f=new XmlBeanFactory(r);
		Employee a1=(Employee)f.getBean("ab");
		System.out.println("Employee Inforamtion is,");
		a1.disp();
	}
}
