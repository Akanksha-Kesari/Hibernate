package com.web.spring;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class MySpringBootJspApplication {
		public static void main(String[] args) {
		SpringApplication.run(MySpringBootJspApplication.class, args);
		System.out.println("Server is UP");
		

	}
}
