package com.spring.aop;

public interface EmployeeService {

	public void getEmployeebyName(String name);
	
}
