package com.web.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.web.spring.model.Employee;
@Service("empserv")
public class EmployeeImpl implements EmployeeInterface{
  static List<Employee> elist=new ArrayList<Employee>();
   static
   {
	   elist.add(new Employee(101,"Ravic"));
	   elist.add(new Employee(102,"Amit"));
   }
	
	@Override
	public List<Employee> getEmp() {
		// TODO Auto-generated method stub
		return elist;
	}

	@Override
	public void addEmployee(Employee e) {
		elist.add(e);
		
	}

}
