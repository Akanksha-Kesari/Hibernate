package com.spring.aop;

public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public void getEmployeebyName(int id, String name) {
		// TODO Auto-generated method stub
		System.out.println("Inside EmployeeByName");
		System.out.println("Eid  "+id+" Name  "+name);
		
	}

	@Override
	public void addEmployee() {
		// TODO Auto-generated method stub
		System.out.println("inside addemployee and Employee Created ");
	}

}
