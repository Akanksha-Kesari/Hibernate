package com.spring.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	  ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	  EmployeeServiceImpl service=context.getBean("empservimpl",EmployeeServiceImpl.class);
	  service.addEmployee();
	  service.getEmployeebyName(1, "abc");

	}

}
