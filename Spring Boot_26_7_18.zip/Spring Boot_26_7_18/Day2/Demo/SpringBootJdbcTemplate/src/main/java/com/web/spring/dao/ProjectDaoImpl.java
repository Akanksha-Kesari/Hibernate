package com.web.spring.dao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.web.spring.bean.Project;
@Repository("projrepo")
public class ProjectDaoImpl implements ProjectDao {
@Autowired
JdbcTemplate temp;
	@Override
public List<Project> getAllProjects() throws Exception {
	// TODO Auto-generated method stub
return temp.query("select * from myproject", 
		new ProjectRowMapper());
	}
	
	@Override
	public void addProject(Project proj) throws Exception {
		String query="insert into myproject(pid,name,duration) "
				+ "values(?,?,?)";
	Object[] args=new Object[]{proj.getId(),
			proj.getName(),proj.getDuration()};	
	int out=temp.update(query, args);
	if(out!=0)
	{
		System.out.println("Project Saved with id "+proj.getId());
	}
		else
	{
		System.out.println("Project not saved ");
	}
	
	}
	
}


