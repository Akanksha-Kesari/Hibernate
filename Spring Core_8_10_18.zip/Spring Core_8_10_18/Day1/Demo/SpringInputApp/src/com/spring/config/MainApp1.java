package com.spring.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.model.Employee1;

public class MainApp1 {
public static void main(String[] args) {
ApplicationContext context= 
	new ClassPathXmlApplicationContext("com/spring/model/bean.xml");
Employee1   obj1= (Employee1) context.getBean("emp");
obj1.setId(101);
obj1.setName("ravic");
System.out.println(obj1.getId()+"  "+obj1.getName());
Employee1   obj2= (Employee1) context.getBean("emp");
System.out.println(" Singleton second Request" +obj2.getId()+"  "+obj2.getName());

Employee1   obj3= (Employee1) context.getBean("emp1");
obj3.setId(1201);
obj3.setName("Ajay");
System.out.println(obj3.getId()+"  "+obj3.getName());
Employee1   obj4= (Employee1) context.getBean("emp1");
System.out.println(obj4.getId()+"  "+obj4.getName());
	}

}
