package com.web.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
@Configuration
public class BeanConfig {
	@Bean
	public InternalResourceViewResolver  setUp()
	{
		InternalResourceViewResolver res=new InternalResourceViewResolver();
		res.setPrefix("/WEB-INF/jsp/");
		res.setSuffix(".jsp");
		return res;
			
	}

}
