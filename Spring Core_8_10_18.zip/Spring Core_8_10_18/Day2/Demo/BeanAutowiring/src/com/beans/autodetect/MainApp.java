package com.beans.autodetect;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class MainApp {
public static void main(String[] args) {
ApplicationContext context=new
ClassPathXmlApplicationContext("com/beans/autodetect/spring.xml");
Customer c=(Customer)context.getBean("custBean");
System.out.println(c);
	}
}
