package com.beans.cons;
public class EmployeeBean {
	private String fullName;
	private DepartmentBean deptBean;
public EmployeeBean(String fullName, DepartmentBean deptBean) {
	super();
	this.fullName = fullName;
	this.deptBean = deptBean;
	}

public String getFullName() {
		return fullName;
	}
	
	public DepartmentBean getDeptBean() {
		return deptBean;
	}
	
	}
