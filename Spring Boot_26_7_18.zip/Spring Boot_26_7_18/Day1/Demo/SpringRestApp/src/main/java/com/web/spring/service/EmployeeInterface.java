package com.web.spring.service;
import java.util.List;
import com.web.spring.model.Employee;
public interface EmployeeInterface {
public List<Employee> getEmp();
public void addEmployee(Employee e);
}
