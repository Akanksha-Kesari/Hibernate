package com.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.spring.model.Employee;
import com.spring.model.Employee1;
import com.spring.model.HelloWrold;
@Configuration
public class AppConfig {
@Bean(name="helloBean")	
public HelloWrold helloWorld()
	{
   		return  new HelloWrold();
	}

@Bean(name="empBean")	
public Employee getEmp()
	{
	Employee e=new Employee();
	e.setId(201);
	e.setName("Ajay");
	e.setSal(8989.90f);
   	return  e;
	}

@Bean(name="empBean1")	
public Employee1 getEmp1()
	{
	return new Employee1(301, "Amay", 56788.90f);
	}

}
