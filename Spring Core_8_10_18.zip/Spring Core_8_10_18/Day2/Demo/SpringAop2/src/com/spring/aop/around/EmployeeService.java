package com.spring.aop.around;
public interface EmployeeService {
	public void getEmployeebyName(String name);
	
}
