package com.spring.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.model.Employee2;

public class MainApp1 {
public static void main(String[] args) {
ApplicationContext context= 
	new ClassPathXmlApplicationContext("com/spring/model/bean.xml");
Employee2 e=(Employee2) context.getBean("emp");
Employee2 e1=(Employee2) context.getBean("emp1");

	}

}
