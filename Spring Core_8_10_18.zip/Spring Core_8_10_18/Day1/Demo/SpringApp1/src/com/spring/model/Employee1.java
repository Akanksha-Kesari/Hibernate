package com.spring.model;

public class Employee1 {
	int id;
	String name;
	float sal;
	public Employee1(int id, String name, float sal) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
	}
	
	@Override
	public String toString() {
		return "Employee1 [id=" + id + ", name=" + name + ", sal=" + sal + "]";
	}
	
}
