package com.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import com.entity.Employee;
public class UpdateTest {
	public static void main(String[] args) {
		AnnotationConfiguration cfg= new AnnotationConfiguration();
		SessionFactory sf= cfg.configure().buildSessionFactory();
		Session s=sf.openSession();
		Transaction  tx=s.beginTransaction();
	
	Employee emp= (Employee)s.get(Employee.class, new Integer(101)) ;

	System.out.println("Name "+emp.getName());
	
	emp.setName("Aryan");
	
	System.out.println("Name "+emp.getName());
	
	tx.commit();
	s.close();
	
	
	
	
	
	}

}
