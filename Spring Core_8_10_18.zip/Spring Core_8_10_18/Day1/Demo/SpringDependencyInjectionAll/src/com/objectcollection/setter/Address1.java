package com.objectcollection.setter;

public class Address1
{
	String city;
	String state;
	public Address1(String city, String state) {
	super();
	this.city = city;
	this.state = state;
	}
	public String toString()
	{
		return "City "+city+" state  "+state;
	}
}
