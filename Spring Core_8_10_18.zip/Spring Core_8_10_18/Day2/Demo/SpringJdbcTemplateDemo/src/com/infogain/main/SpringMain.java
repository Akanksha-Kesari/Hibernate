package com.infogain.main;
import java.util.Iterator;
/*
 * 
 * Employee.sql
	CREATE TABLE Employee (
  	id int not null,
  	name varchar(20) DEFAULT null,
  	role varchar(20) DEFAULT null,
  	PRIMARY KEY (id)
	);
	
 * 
 */
import java.util.List;
import java.util.Random;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infogain.jdbc.DataAccess;
import com.infogain.model.Employee;
public class SpringMain {
	public static void main(String[] args) {
	ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");	
				//To use JdbcTemplate
		 
	DataAccess employeeDAO = ctx.getBean("employeeDAOJDBCTemplate", DataAccess.class);
				
		Employee emp = new Employee();
		emp.setId(301);
       emp.setName("Abhi");
        emp.setRole("Tester");
        employeeDAO.save(emp);
		
	
    	List<Employee> empList = employeeDAO.getAll();
		System.out.println("****List of Employee******");
		   for(Employee e:empList)  
	       System.out.println(e);  

/*Iterator<Employee> itr=empList.iterator();
while (itr.hasNext())
{
	Employee e1=itr.next();
	System.out.println(e1);
}*/
		System.out.println("*******DONE*******");
	}
}
