package com.objectcollection.setter;
import java.util.Iterator;
import java.util.List;
public class Employee
{
	int eid;
	String name;
	List<Address1> add;
	
public int getEid() {
		return eid;
	}



	public void setEid(int eid) {
		this.eid = eid;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public List<Address1> getAdd() {
		return add;
	}



	public void setAdd(List<Address1> add) {
		this.add = add;
	}


public void disp()
{
	System.out.println("Employee id "+eid+" Name  "+name);
	Iterator<Address1> itr=add.iterator();
	while(itr.hasNext()){
	Address1 c=itr.next();
	System.out.println(c);
	}

}
}
