package com.spring.model;

public class Employee2 {

	String name;
	int age;
	float sal;
	public Employee2(String name, float sal,int age) {
		super();
		this.name = name;
		this.age = age;
		this.sal = sal;
		System.out.println("Inside First Constructor...");
	}
	
	
	public Employee2(String name, int age) {
		super();
		this.name = name;
		this.age = age;
		System.out.println("Inside second Constructor...");
	}
	
	public Employee2(String name, float sal) {
		super();
		this.name = name;
		this.sal = sal;
		System.out.println("Inside third Constructor...");
	}
	
	
	
	}
