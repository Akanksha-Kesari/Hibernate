package com.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import com.entity.Employee;
public class MainApp {
public static void main(String[] args) {
AnnotationConfiguration cfg= new AnnotationConfiguration();
SessionFactory sf= cfg.configure().buildSessionFactory();
Session s=sf.openSession();
Employee emp=new Employee();
emp.setEid(101);
emp.setName("Deepak");
emp.setMobno("98989999");
Transaction  tx=s.beginTransaction();
s.save(emp);

// Load
/*Employee emp= (Employee)s.load(Employee.class, new Integer(101)) ;

//Employee emp= (Employee)s.get(Employee.class, new Integer(101)) ;
*/
/*System.out.println("Employee Info ...");

System.out.println(" Eid "+emp.getEid()+" Name "+emp.getName()
+"Mob No "+emp.getMobno());*/

System.out.println("Object Persisted....");
tx.commit();
s.close();


		
		
	}

}
