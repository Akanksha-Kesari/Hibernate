package com.spring.aop;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public void addEmployee() {
		// TODO Auto-generated method stub
		System.out.println("employee added hihihi");
	}
	
	

	
	
}
