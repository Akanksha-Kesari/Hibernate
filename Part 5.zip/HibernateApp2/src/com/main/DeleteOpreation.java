package com.main;import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import com.entity.Employee;
public class DeleteOpreation {
public static void main(String[] args) {
AnnotationConfiguration cfg= new AnnotationConfiguration();
SessionFactory sf= cfg.configure().buildSessionFactory();
		Session s=sf.openSession();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the id to be deleted...");
	
	int id=sc.nextInt();
	  Transaction tx=s.beginTransaction();
	
	Employee e=(Employee) s.load(Employee.class, id);
	s.delete(e);
	System.out.println("Delete");
	tx.commit();
	s.close();
	
	
		

	}

}
