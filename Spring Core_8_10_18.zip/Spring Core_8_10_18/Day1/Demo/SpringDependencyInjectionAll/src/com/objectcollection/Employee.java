package com.objectcollection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
public class Employee
{
	int eid;
	String name;
	List<Address1> add;
	public Employee(int eid, String name, List<Address1> add) {
	this.eid = eid;
	this.name = name;
	this.add = add;
	}
	
public void disp()
{
	System.out.println("Employee id "+eid+" Name  "+name);
	Iterator<Address1> itr=add.iterator();
	while(itr.hasNext()){
	Address1 c=itr.next();
	System.out.println(c);
	}

}
}
