package com.web.spring.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.web.spring.bean.Project;
import com.web.spring.dao.ProjectDao;
@RestController
@RequestMapping(value="/service")
public class ProjectService {
	@Autowired
	private ProjectDao iDao;
	
	@RequestMapping(value="getprojects",method=RequestMethod.GET,
			produces="application/json")
	public List<Project> getAllProject()throws Exception
	{
		
		return iDao.getAllProjects();
	}
	
	@RequestMapping(value="addproject",method=RequestMethod.POST,
			produces="application/json",consumes="application/json")
	public String addProject(@RequestBody Project p)throws Exception
	{
		iDao.addProject(p);
		return "Project added";
	}

	
	
}