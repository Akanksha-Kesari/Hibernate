package com.spring.aop;

public interface EmployeeService {
	public void getEmployeebyName(int id,String name);
	public void addEmployee();

}
