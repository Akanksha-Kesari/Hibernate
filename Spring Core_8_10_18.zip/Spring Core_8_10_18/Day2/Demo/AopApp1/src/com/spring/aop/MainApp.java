package com.spring.aop;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class MainApp {
	public static void main(String[] args) {
	ApplicationContext context= new ClassPathXmlApplicationContext("spring.xml");
	EmployeeService emp=  (EmployeeService) context.getBean("empservimpl");
	emp.getEmployeebyName(101,"Ravic");
    emp.addEmployee();

	}

}
