package com.spring.model;

import java.util.Scanner;

public class Employee {
	String name;

	public Employee(String name) {
		super();
		this.name = name;
	}

	public static Employee getEmp()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		String name=sc.nextLine();
		return new Employee(name);
		}
	
	public void disp()
	{
		System.out.println("Emp name "+name);
	}
	
	
}
