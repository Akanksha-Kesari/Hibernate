package diby.constructor;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.*;
import java.io.FileInputStream;

public class Test {
	public static void main(String[] args) {
		
Resource r=new ClassPathResource("diby/constructor/applicationContext.xml");
		BeanFactory factory=new XmlBeanFactory(r);
		Employee employee =(Employee)factory.getBean("employeeBean");
		employee.show();
		
	}
}
